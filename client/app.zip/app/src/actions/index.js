import { GET, POST } from '../services/http';
import {PHOTO_ALBUM_API} from '../config/app';

import {
  LOAD_PHOTOS,
  LOAD_PHOTOS_SUCCESS,
  LOAD_PHOTOS_FAIL,
  UPDATE_sELECTED_LIST
} from "../constants/actionTypes";

export const loadUserPhotos = () => async dispatch => {
  dispatch({
    type: LOAD_PHOTOS
  })

  try {

    const response = await GET(PHOTO_ALBUM_API);
        const data = response.data;

        let arr = [];
        if (data) {
          arr = data.entries;
        }

        dispatch({
          type: LOAD_PHOTOS_SUCCESS,
          photoList: arr,
        })

  } catch (err) {
    dispatch({
      type: LOAD_PHOTOS_FAIL
    })
  }

};

export const saveSelectedPhotos = (list) => dispatch => {
  console.log("list", list)
  return dispatch({ 
    type: UPDATE_sELECTED_LIST,
    selectedPhotos: list
  });
};