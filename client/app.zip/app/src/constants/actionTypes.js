/**
 * load up[loaded photos
 */
export const LOAD_PHOTOS = "LOAD_PHOTOS";
export const LOAD_PHOTOS_SUCCESS = "LOAD_PHOTOS_SUCCESS";
export const LOAD_PHOTOS_FAIL = "LOAD_PHOTOS_FAIL";

/**
 * save user selected images
 */
export const UPDATE_sELECTED_LIST = "UPDATE_sELECTED_LIST";
