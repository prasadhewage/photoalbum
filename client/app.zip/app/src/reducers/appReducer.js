import {
    LOAD_PHOTOS,
    LOAD_PHOTOS_SUCCESS,
    LOAD_PHOTOS_FAIL,
    UPDATE_sELECTED_LIST
} from '../constants/actionTypes';

const initialState = {
    photos_loading: null,
    photoList: null,
    selectedPhotoList: {}
};

const appReducer = (state = initialState, action) => {
    switch (action.type) {
        case LOAD_PHOTOS:
            return { ...state, photos_loading: true};

        case LOAD_PHOTOS_SUCCESS:
            return { ...state, photos_loading: false, photoList: action.photoList};

        case LOAD_PHOTOS_FAIL:
            return { ...state, photos_loading: false };

        case UPDATE_sELECTED_LIST:
            return { ...state, selectedPhotoList: action.selectedPhotos };

        default:
            return state;
    }
}

export default appReducer;