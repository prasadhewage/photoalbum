import React from 'react';
import Photo from '../../components/photo';
import PhotoGrid from '../../components/selectedPhotos';

class HomeContainer extends React.Component {
    constructor(props) {
        super(props);

        this.state = {
            selectedPhotos: {},
            listOfImagesSelected: [],
            maxNumberOfImagesSelected: false
        }

        this.selectableMaxNumberOfPhotos = 9;
    }

    /**
     * load uploaded pictures on component mount
     */
    componentDidMount() {
        this.props.loadUserPhotos();
    }

    /**
     * update state with selected photos
     */
    handleOnPhotoSelect(photo) {
        let { selectedPhotos, maxNumberOfImagesSelected } = this.state;
        const selectedPhotoArray = Object.keys(selectedPhotos);

        if(!selectedPhotos.hasOwnProperty(photo.id)) {
            if(selectedPhotoArray.length <= this.selectableMaxNumberOfPhotos - 1) {
                selectedPhotos[photo.id] = {...photo, order: selectedPhotoArray.length + 1};
                maxNumberOfImagesSelected = false;
            } else {
                maxNumberOfImagesSelected = true;
            }
        } else {
            delete selectedPhotos[photo.id];
            maxNumberOfImagesSelected = false;
        }

        
        this.setState({selectedPhotos, maxNumberOfImagesSelected})
    }

    render () {
        const { photosLoading, photoList, selectedPhotoList } = this.props;
        const { selectedPhotos, maxNumberOfImagesSelected } = this.state;
        let photoGrid = [];

        photoGrid = photoList && photoList.map((photo, key) => {
            let isPhotoSelected = (selectedPhotos.hasOwnProperty(photo.id))? true : false;
            return (
                <Photo src={photo.picture} id={photo.id} isSelected={isPhotoSelected} handleOnClick={(photoData) => this.handleOnPhotoSelect(photoData)} key={photo.id} />
            )
        })

        return (
            <div className="App">
                {
                    (photosLoading)?
                    <p>loading..</p>
                    :
                    <>
                        <PhotoGrid selectedPhotos={selectedPhotos} />
                        <div className="container">
                            <h2 className="text-center">Uploaded images</h2>
                            {
                                (maxNumberOfImagesSelected)?
                                <p>Maximum number of {this.selectableMaxNumberOfPhotos} photos are selected.</p>
                                :
                                null
                            }
                            <div className="row">
                                {photoGrid}
                            </div>
                        </div>
                    </>
                }
            </div>
        )
    }
}

export default HomeContainer;