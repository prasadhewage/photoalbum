import { connect } from "react-redux";
import { bindActionCreators } from "redux";
import { loadUserPhotos, saveSelectedPhotos } from "../../actions"
import HomeContainer from "./homeContainer";

const mapStateToProps = state => ({
    photosLoading: state.app.photos_loading,
    photoList: state.app.photoList,
    selectedPhotoList: state.app.selectedPhotoList,
  })

const mapDispatchToProps = dispatch => bindActionCreators({
    loadUserPhotos,
    saveSelectedPhotos
}, dispatch)
  
export default connect(
    mapStateToProps,
    mapDispatchToProps
)(HomeContainer)